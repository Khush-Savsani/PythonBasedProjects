import java.util.*;
import java.sql.*;

class Login
{
    Scanner sc = new Scanner(System.in);
    String username, password, confirmPassword;

    void login(Connection con) throws Exception
    {
        System.out.println("Log-In to Create Your Account:\n");

        System.out.print("Enter Your Username (must be greater or equal to than 7 characters): ");

        while(true)
        {
            username = sc.nextLine();
            if(username.length()>=7)
            {
                while(true)
                {
                    System.out.print("\nEnter your Password (must be greater or equal to than 8 characters): ");
                    password = sc.next();
                    if(password.length()>=8)
                    {
                        while(true)
                        {
                            System.out.println("\nConfirm Your Password.");
                            System.out.print("Enter Confirm Password: ");
                            confirmPassword = sc.next();
                            if(confirmPassword.equals(password))
                            {
                                System.out.println("Password added successfully.");
                                break;
                            }
                            else
                            {
                                System.out.println("\nConfirmed Password is Invalid. Please enter Confirm Password carefully.");
                            }
                        }
                        break;
                    }
                    else
                    {
                        System.out.println("Password is Invalid. Please enter Password carefully.\n");
                    }
                }
                break;
            }
            else
            {
                System.out.println("Username is Incorrect. Please enter valid Username.");
            }
        }
        String sql = "insert into users (userName, password) values (?, ?)";

        PreparedStatement pst = con.prepareStatement(sql);
        pst.setString(1, username);
        pst.setString(2, password);
        int r = pst.executeUpdate();
        if(r>0)
        {
            System.out.println("\nUser Details are saved Successfully.");
        }
        else
        {
            System.out.println("Error!");
        }
    }
    void updateRecord(Connection con) throws Exception
    {
        while(true)
        {
            System.out.print("Enter Your Login Id: ");
            int loginId = sc.nextInt();
            sc.nextLine();
            
            System.out.print("Enter Your Username (must be greater or equal to than 7 characters): ");

            while(true)
            {
                username = sc.nextLine();
                if(username.length()>=7)
                {
                    while(true)
                    {
                        System.out.print("\nEnter your Password (must be greater or equal to than 8 characters): ");
                        password = sc.next();
                        if(password.length()>=8)
                        {
                            while(true)
                            {
                                System.out.println("\nConfirm Your Password.");
                                System.out.print("Enter Confirm Password: ");
                                confirmPassword = sc.next();
                                if(confirmPassword.equals(password))
                                {
                                    System.out.println("Password added successfully.");
                                    break;
                                }
                                else
                                {
                                    System.out.println("\nConfirmed Password is Invalid. Please enter Confirm Password carefully.");
                                }
                            }
                            break;
                        }
                        else
                        {
                            System.out.println("Password is Invalid. Please enter Password carefully.\n");
                        }
                    }
                    break;
                }
                else
                {
                    System.out.println("Username is Incorrect. Please enter valid Username.");
                }
            }
            String sql1 = "update users set userName = ?, password = ? where loginId = ?";
            PreparedStatement pst1 = con.prepareStatement(sql1);
            pst1.setString(1, username);
            pst1.setString(2, password);
            pst1.setInt(3, loginId);
            int r1 = pst1.executeUpdate();
            if(r1>0)
            {
                System.out.println("\nDetails are Updated Successfully.");
                break;
            }
            else
            {
                System.out.println("Error!");
            }
        }
    }
}

class DigitalMall
{
    public static void main(String[] args) throws Exception {

        String dburl = "jdbc:mysql://localhost:3306/digitalmall";
        String dbuser = "root"; // by default username.
        String dbpass = "";
        String drivername = "com.mysql.cj.jdbc.Driver";
        Class.forName(drivername);
        Connection con = DriverManager.getConnection(dburl, dbuser, dbpass);
        if(con != null)
        {
            System.out.println("Connection Successfull.");
        }
        else
        {
            System.out.println("Connection Failed.");
        }

        Scanner sc = new Scanner(System.in);
        System.out.println("\n-*-*-*-*-*-*-*-*-*-*WELCOME TO DIGITAL MALL*-*-*-*-*-*-*-*-*-*-\n");

        Login log_in = new Login();
        
        int ch;
        do
        {
            System.out.println("Press 1: To Login\nPress 2: To Update your Log-In Details\nPress 3: To Exit the System\n");
            System.out.print("Enter Your Choice: ");
            ch = sc.nextInt();
            sc.nextLine();
            switch(ch)
            {
                case 1:
                {
                    log_in.login(con);
                    break;
                }
                case 2:
                {
                    log_in.updateRecord(con);
                    break;
                }
                case 3:
                {
                    System.out.println("Exiting the Application...");
                    break;
                }
                default:
                {
                    System.out.println("Invalid Choice");
                    break;
                }
            }
        }while(ch !=3);
    }
}